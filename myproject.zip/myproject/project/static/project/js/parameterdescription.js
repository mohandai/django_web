function popDescription(id)
{
	//var x = document.getElementById('gripdescription');
	var x = document.getElementById(id);
	x.style.display = (x.style.display == 'none')?'block':'none';

}

