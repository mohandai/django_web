
function checklogin()
{
	window.location.href = '/login';
	//if(sessionStorage.getItem("loginSuccess") == "true")
	//{
		
		//window.location.href = 'login/index.html';
		
		//document.querySelector('.cont_forms').className = "cont_forms";
	    //window.location.href = 'login/index.html';
		//document.querySelector('.cont_form_login').style.display = "none";
		//document.querySelector('.cont_form_sign_up').style.opacity = "0"; 
		//document.querySelector('.col_md_logout').style.display = "block";
        //document.querySelector('.col_md_login').style.display = "none";
		//document.querySelector('.cont_form_login').style.opacity = "0";
		//document.querySelector('.col_md_sign_up').style.display = "block";
		//document.querySelector('.cont_form_sign_up').style.display = "none";
	    
		//window.location.href = 'login/index.html';
	//}else{
		//window.location.href = 'login/index.html';
	//}
}


/*
$(document).ready(function(){
  $("#login_button").click(function(){
    $("p").hide();
  });
});
*/